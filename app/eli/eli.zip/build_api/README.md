# APIs

An [example](server.py) for now that shows how to build a simple API.
Use the API via a browser, or use [curl](useapi.txt).
