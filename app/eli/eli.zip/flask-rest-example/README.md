# Install Dependencies
For python 2.x
``
pip install -r requirements.txt 
``
For python 3.x
``
pip3 install -r requirements.txt 
``


# Run app
python app.py
