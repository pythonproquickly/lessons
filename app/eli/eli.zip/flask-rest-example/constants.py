HOST = 'localhost'
DB_NAME = 'flask_tutorial' 
USERNAME = 'root'
PASSWORD = 'root'
PORT = 3306